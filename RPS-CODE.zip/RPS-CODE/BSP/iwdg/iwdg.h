#ifndef __IWDG_H__
#define __IWDG_H__
#include "stm32f4xx_iwdg.h"
void IWDG_Configuration(void);
#endif
