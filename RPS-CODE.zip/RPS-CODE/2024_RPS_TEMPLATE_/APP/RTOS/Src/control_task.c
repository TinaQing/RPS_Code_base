#include "control_task.h"


int time_tick = 0;

void control_task(void)
{
	time_tick++;


	
	
	
}


void control_task_Init(void)
{
	
}
